insert into catalog_sales (select * from csv);
rollback;

